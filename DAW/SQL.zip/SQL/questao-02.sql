DESC country;
SELECT country FROM country;