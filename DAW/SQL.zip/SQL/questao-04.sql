DESC inventory;
SELECT COUNT(film_id) FROM inventory;